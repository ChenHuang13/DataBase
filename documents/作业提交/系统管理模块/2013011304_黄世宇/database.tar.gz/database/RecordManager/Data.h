//
// Created by huangsy13 on 11/13/15.
//


//Data类：一条数据的类，记录数据信息。

#ifndef DATABASE_DATA_H
#define DATABASE_DATA_H

class Data{
public:

};

#endif //DATABASE_DATA_H
