DROP INDEX orders(quantity);
DROP INDEX orders(book_id);
CREATE INDEX orders(book_id);
DROP INDEX orders(quant);
DROP INDEX tb(book_id);
SELECT * from orders WHERE book_id =208522;