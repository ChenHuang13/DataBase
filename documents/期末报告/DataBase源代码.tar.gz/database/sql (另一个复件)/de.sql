DROP INDEX orders(quantity);
