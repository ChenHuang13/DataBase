UPDATE book SET title='A Cherished Reward (Homespun Series)',id=250000 WHERE authors='Anthony Boucher';
SELECT * FROM book WHERE authors='Anthony Boucher'; 
