//
// Created by huangsy13 on 12/23/15.
//

#ifndef DATABASE_RECORDMANAGER_H
#define DATABASE_RECORDMANAGER_H

class RecordManager{
public:

};

#endif //DATABASE_RECORDMANAGER_H
