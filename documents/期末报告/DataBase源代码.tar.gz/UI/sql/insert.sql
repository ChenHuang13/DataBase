INSERT INTO book VALUES 
 (200100,'Anyone Can Have a Happy',null,103343,3358);