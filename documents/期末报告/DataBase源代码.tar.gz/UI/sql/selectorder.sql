SELECT * from orders WHERE quantity > 8; 
