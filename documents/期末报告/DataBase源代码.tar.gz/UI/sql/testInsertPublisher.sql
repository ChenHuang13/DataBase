INSERT INTO publisher VALUES 
 (13);

INSERT INTO publisher VALUES 
 (25);

INSERT INTO publisher VALUES 
 (38);

INSERT INTO publisher VALUES 
 (49);

INSERT INTO publisher VALUES 
 (546);
