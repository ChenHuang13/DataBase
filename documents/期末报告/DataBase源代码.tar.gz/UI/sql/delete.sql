DELETE FROM book WHERE title='Thirteen Ways to Sink a Sub';
DELETE FROM orders WHERE quantity= 9;
DELETE FROM beek WHERE title='New Voices in Science Fiction';
DELETE FROM book WHERE titl='Humans (Neanderthal Parallax)';