CREATE INDEX orders(quantity); 
