CREATE INDEX orders(book_id);
CREATE INDEX ord(book_id);
CREATE INDEX orders(booid);
CREATE INDEX orders(quantity);
CREATE INDEX ods(quantity);
CREATE INDEX orders(quantity);