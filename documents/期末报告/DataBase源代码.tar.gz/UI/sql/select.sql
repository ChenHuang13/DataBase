SELECT title,id,copies,authors from book WHERE id > 249900 AND id <= 249992 AND copies > 3000 AND copies<=5335 AND title <='Self-Portrait With Turtles: A Memoir';
SELECT title,authors,id from book WHERE id< 200020;
SELECT * from orders WHERE customer_id =303017;