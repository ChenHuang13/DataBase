UPDATE eek SET title='A Cherished Reward (Homespun Series)',id=250001 WHERE authors='Anthony Boucher';
UPDATE book SET ttle='A Cherished Reward (Homespun Series)',id=250001 WHERE authors='Anthony Boucher';
UPDATE book SET title='A Cherished Reward (Homespun Series)',id=250001 WHERE autors='Anthony Boucher';
UPDATE book SET title='A Cherished Reward (Homespun Series)',idd=250001 WHERE autors='Anthony Boucher';
UPDATE book SET tite='A Cherished Reward (Homespun Series)',idd=250001 WHERE autors='Anthony Boucher';
UPDATE book SET title='A Cherished Reward (Homespun Series)',id=250001 WHERE authors='Anthony Boucher';