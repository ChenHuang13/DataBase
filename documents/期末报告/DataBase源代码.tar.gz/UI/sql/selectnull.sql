SELECT * from book WHERE authors is null; 
