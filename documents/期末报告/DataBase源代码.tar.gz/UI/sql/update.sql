SELECT * FROM book WHERE authors='Anthony Boucher'; 
UPDATE book SET title='Nine Times Nine' WHERE authors='Anthony Boucher';
SELECT * FROM book WHERE authors='Anthony Boucher';
UPDATE book SET title='A Cherished Reward (Homespun Series)',id=250001 WHERE authors='Anthony Boucher';
SELECT * FROM book WHERE authors='Anthony Boucher';