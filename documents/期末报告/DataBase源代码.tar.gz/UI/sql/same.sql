INSERT INTO book VALUES 
 (200001,'Marias Diary (Plus S.)','Mark P. O. Morford',100082,5991),
 (200002,'Standing in the Shadows','Richard Bruce Wright',101787,2900),
 (200003,'Children of the Thunder','Carlo DEste',102928,3447);