SHOW TABLES;
DESC customer;
DESC ook;
