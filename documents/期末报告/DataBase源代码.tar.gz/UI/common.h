#ifndef COMMON
#define COMMON

#include "database/dataBaseManager.h"

DataBaseManager databaseManager;

//char* c_str(QString str){
//    QByteArray ba = str.toLatin1();
//    char* ch = new char;
//    ch = ba.data();
//    return ch;
//}

#endif // TEST

