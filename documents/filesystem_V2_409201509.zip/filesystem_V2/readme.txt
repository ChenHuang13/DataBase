ppt在ppt(wps)目录下
源代码在bufmanager fileio utils目录下，还有testfilesystem.cpp
可执行在Debug目录下，运行命令
$./testfilesystem
开发环境可以用eclipse

sql测试语句在testsql目录下

