//
// Created by huangsy13 on 11/30/15.
//

#ifndef DATABASE_INDEXSCAN_H
#define DATABASE_INDEXSCAN_H

class IX_IndexScan {
public:
    IX_IndexScan  (){}
    ~IX_IndexScan (){}
    void OpenScan      (){}

    void GetNextEntry  (){}

    void CloseScan     (){}

};

#endif //DATABASE_INDEXSCAN_H
