//
// Created by huangsy13 on 11/30/15.
//

#ifndef DATABASE_INDEXHANDLE_H
#define DATABASE_INDEXHANDLE_H

class IndexHandle {
public:
    IndexHandle();
    ~IndexHandle();
    void InsertEntry(){}

    void DeleteEntry(){}

    void ForcePages(){}

};

#endif //DATABASE_INDEXHANDLE_H
