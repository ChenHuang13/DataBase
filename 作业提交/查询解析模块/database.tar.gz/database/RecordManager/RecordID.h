//
// Created by huangsy13 on 11/14/15.
//

//通过RecordID定位一条记录

#ifndef DATABASE_RECORDID_H
#define DATABASE_RECORDID_H

class RecordID{
public:
	int page;
	int slot;
};

#endif //DATABASE_RECORDID_H
