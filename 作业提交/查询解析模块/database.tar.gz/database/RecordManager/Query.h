//
// Created by huangsy13 on 11/13/15.
//

//Query类：抽象查询请求，包含查询的区间和字段的值。

#ifndef DATABASE_QUERY_H
#define DATABASE_QUERY_H

class Query{
public:

};

#endif //DATABASE_QUERY_H
