//
// Created by huangsy13 on 11/13/15.
//

//Table类：表项基类，提供表的创建和查询。

#ifndef DATABASE_TABLE_H
#define DATABASE_TABLE_H

class Table{
public:

};

#endif //DATABASE_TABLE_H
